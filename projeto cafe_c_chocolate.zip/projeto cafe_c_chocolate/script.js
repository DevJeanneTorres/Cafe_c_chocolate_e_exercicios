// Função para pegar os parâmetros da URL
function getURLParameter(name) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(name);
}

// Preencher os dados com os valores passados pela URL
document.getElementById("nome").textContent = getURLParameter('nome');
document.getElementById("tel_cel").textContent = getURLParameter('tel_cel');
document.getElementById("mensagem").textContent = getURLParameter('mensagem');

// Exibir o tipo de feedback
let feedback = [];
if (getURLParameter('feedback')) {
    const feedbackValues = getURLParameter('feedback').split(',');
    if (feedbackValues.includes('elogios')) feedback.push('Elogios');
    if (feedbackValues.includes('sugestoes')) feedback.push('Sugestões');
    if (feedbackValues.includes('reclamacoes')) feedback.push('Reclamações');
}
document.getElementById("feedback").textContent = feedback.length ? feedback.join(", ") : "Nenhum feedback selecionado.";